function [features, featureMetrics]= helperORBFeatureExtractorFunction(I)
% helperORBFeatureExtractorFunction Implements the ORB feature extraction 
% used in bagOfFeatures.
%
%   This is an example helper function that is subject to change or removal 
%   in future releases.

%   Copyright 2021 The MathWorks, Inc.

numPoints   = 1000;   % specifies that we are identifying 1000 feature points on the grayscale image

% Detect ORB features
Igray  = im2gray(I);  % converts the input image to grayscale image 

points = detectORBFeatures(Igray, 'ScaleFactor', 1.2, 'NumLevels', 8);  % we find the places where we can find the interesting features, like the places with very high gradient 

% Select a subset of feature points , uniformly distributed throughout the image
points = selectUniform(points, numPoints, size(Igray, 1:2));

% Extract the actual features at each point which are also knowan as
% descriptors 
features = extractFeatures(Igray, points);

% Compute the Feature Metric. Use the variance of features as the metric
featureMetrics = var(single(features.Features),[],2);

